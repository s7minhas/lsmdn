Latent Space Model for Dynamics Networks
---
