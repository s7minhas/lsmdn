#'lsmdn - latent space model for dynamic networks
#'
#'@author Shahryar Minhas <shahryar.minhas@@duke.edu>
#'@docType package
#'@name lsmdn
#'@importFrom Rcpp evalCpp
#'@useDynLib lsmdn
#'@aliases lsmdn lsmdn-package
NULL